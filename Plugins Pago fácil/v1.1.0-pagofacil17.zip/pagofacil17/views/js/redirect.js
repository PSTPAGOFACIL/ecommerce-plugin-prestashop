
(function() {
    var elem = document.getElementById('url_trx');
    if (elem && elem.value) {
        window.location = elem.value;
    }
})();
